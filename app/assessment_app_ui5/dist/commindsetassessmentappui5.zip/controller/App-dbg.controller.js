sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.mindset.assessmentappui5.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  